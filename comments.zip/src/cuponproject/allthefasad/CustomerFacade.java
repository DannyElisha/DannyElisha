package cuponproject.allthefasad;

public class CustomerFacade extends ClientFacade{

	int CustomerID;
	
	public CustomerFacade(int customerID) {
		super();
		CustomerID = customerID;
	}

	@Override
	public boolean Login(String email, String password) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
