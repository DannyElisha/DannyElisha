package cuponproject.allthefasad;

import java.sql.SQLException;
import java.util.Collection;

import cuponproject.allthebeans.Company;
import cuponproject.allthebeans.Coupon;
import cuponproject.allthebeans.Customer;
import cuponproject.allthedbdao.CompaniesdbDAO;
//contains financial logic of administrator

public class AdminFacade extends ClientFacade{

	public AdminFacade() {
		super();
	}

	@Override
	public boolean Login(String email, String password) {
		// TODO Auto-generated method stub
		return false;
	}
	
//let the administrator create a coompany
	public void createCompany(Company company) throws Exception {
		try {
			if (companiesdbDAO.getAllCompanies() != null)
				if (companiesdbDAO.getAllCompanies().contains(company)) {
					throw new Exception("Failed to create Company. Adding a Company with an existing name is not allowed.");
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		companiesdbDAO.addCompany(company);
	}
//let the administrator remove a coompany

	public void removeCompany(Company company) throws Exception {
		try {
			Collection<Coupon> coupons = cuponsdbDAO.getCompanyCoupons(company.getId());
			for (Coupon c : coupons) {
				cuponsdbDAO.removeCompanyCoupon(c.getId());
				cuponsdbDAO.removeCustomerCoupon(c.getId());
				cuponsdbDAO.deleteCoupon(c);
			}
			companiesdbDAO.deleteCompany(company);
		} catch (Exception e) {
			throw new Exception("Failed to remove Company. Please check the cause for this.");
		}
	}
//let the administrator update a coompany

	public void updateCompany(Company company) throws Exception {
		try {
			companiesdbDAO.updateCompany(company);
		} catch (Exception e) {
			throw new Exception("Error encountered while attempting to update company.Please check the cause for this.");
		}
	}
//show  a company for the administrator

	public Company getCompany(int id) throws Exception {
		try {
			return companiesdbDAO.getOneCompany(id);
		} catch (Exception e) {
			throw new Exception("Error encountered while attempting to retrieve company.Please check the cause for this.");
		}
	}
//show  all the companys for the administrator

	public Collection<Company> getAllCompanies() throws Exception {
		try {
			return companiesdbDAO.getAllCompanies();
		} catch (Exception e) {
			throw new Exception("Error encountered while attempting to retrieve companies.Please check the cause for this.");
		}
	}
//let the admin create a customer
	public void createCustomer(Customer customer) throws Exception {
		if (customerdbDAO.getAllCustomers() != null)
			if (customerdbDAO.getAllCustomers().contains(customer)) {
				throw new Exception("Failed to create Customer. Adding a Custoemr with"
									+ " an existing name is not allowed.");
			}
		customerdbDAO.addCustomer(customer);
	}
//let the admin remove a customer

	public void removeCustomer(Customer customer) throws Exception {
		try {
			Collection<Integer> couponIds = customerdbDAO.getCustomerCoupons(customer.getId());
			for (Integer c : couponIds) {
				cuponsdbDAO.removeCustomerCoupon(c);
			}
			customerdbDAO.deleteCustomer(customer);
		} catch (Exception e) {
			throw new Exception("Error encountered while attempting to delete customer. "
								+ "Please check the cause for this.");
		}
	}
//let the admin update a customer

	public void updateCustomer(Customer customer) throws Exception {
		try {
			customerdbDAO.updateCustomer(customer);
		} catch (Exception e) {
			throw new Exception("Error encountered while attempting to update customer."
					+ "Please check the cause for this.");
		}
	}
// show the admin a customer
	public Customer getCustomer(int id) throws Exception {
		try {
			return customerdbDAO.getOneCustomer(id);
		} catch (Exception e) {
			throw new Exception("Error encountered while attempting to retrieve customer."
					+ "Please check the cause for this.");
		}
	}
//show the admin all the customers

	public Collection<Customer> getAllCustomers() throws Exception {
		try {
			return customerdbDAO.getAllCustomers();
		} catch (Exception e) {
			throw new Exception("Error encountered while attempting to retrieve all customers."
					+ "Please check the cause for this.");
		}
	}

	

	@Override
	public String toString() {
		return "admin";
	}
}
