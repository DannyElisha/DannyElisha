package cuponproject.allthefasad;

public class CompanyFacade extends ClientFacade{
	int CompanyID;
	

	public CompanyFacade(int companyID) {
		super();
		CompanyID = companyID;
	}


	@Override
	public boolean Login(String email, String password) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
