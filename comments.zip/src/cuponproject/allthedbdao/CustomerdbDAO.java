package cuponproject.allthedbdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import cuponproject.allthebeans.Coupon;
import cuponproject.allthebeans.Customer;
import cuponproject.alltheconnectionpool.ConnectionPool;
import cuponproject.allthedao.CustomerDAO;

public class CustomerdbDAO implements CustomerDAO {
	private Connection connection;
	@Override
	public boolean isCustomerExists(String email, String password) {
		// TODO Auto-generated method stub
		return false;
	}
// add a customer
	@Override
	public void addCustomer (Customer customer)throws SQLException {
		try {
			connection = ConnectionPool.getSingeltonInstance().getConnection();

			String createSQL = "INSERT INTO `java project - coupon system`.customers (LASTNAME,FIRSTNAME,PASSWORD) VALUES (?,?,?)";
			PreparedStatement pStatement = connection.prepareStatement(createSQL);
			pStatement.setString(1, customer.getLastName());
			pStatement.setString(2, customer.getFirstName());
			pStatement.setString(3, customer.getPassword());
			pStatement.executeUpdate();

			System.out.println("Customer " + customer.getLastName() + customer.getFirstName() + " was created!");
		} catch (SQLException | InterruptedException e) {
			throw new SQLException("Failed to create a new Customer.");
		} finally {
			ConnectionPool.getSingeltonInstance().restoreConnection(connection);
		}
	}
//update a customer
	@Override
	public void updateCustomer(Customer customer) throws SQLException {
		try {
			ConnectionPool.getSingeltonInstance().getConnection();

			String updateSQL = "UPDATE `java project - coupon system`.customers SET LASTNAME=?, FIRSTNAME=?, PASSWORD=? WHERE ID=?";
			PreparedStatement pStatement = connection.prepareStatement(updateSQL);
			pStatement.setString(1, customer.getLastName());
			pStatement.setString(2, customer.getFirstName());
			pStatement.setString(3, customer.getPassword());
			pStatement.setInt(4, customer.getId());
			pStatement.execute();
			System.out.println("Customer " + customer.getLastName()+ customer.getFirstName()  + " was updated!");
			
		} catch (SQLException | InterruptedException e) {
			throw new SQLException("Failed to update Customer.");
		} finally {
			ConnectionPool.getSingeltonInstance().restoreConnection(connection);
		}
	}
// delete a customer
	@Override
	public void deleteCustomer(Customer customer) throws SQLException {
		try {
			connection = ConnectionPool.getSingeltonInstance().getConnection();
			unlinkAllCustomerCoupon(customer.getId());

			String removeSQL = "DELETE FROM `java project - coupon system`.customers WHERE ID=?";
			PreparedStatement pStatement2 = connection.prepareStatement(removeSQL);
			pStatement2.setInt(1, customer.getId());
			pStatement2.executeUpdate();
			System.out.println("Customer " + customer.getLastName()+ customer.getFirstName() + " ID "
								+ customer.getId() + " was deleted!");
		} catch (SQLException | InterruptedException e) {
			throw new SQLException("Failed to remove Customer from the database.");
		} finally {
			ConnectionPool.getSingeltonInstance().restoreConnection(connection);
		}

	}// get all customers
	@Override
	public ArrayList<Customer> getAllCustomers()throws SQLException {
		ArrayList<Customer> customers = new ArrayList<>();
		try {
			connection = ConnectionPool.getSingeltonInstance().getConnection();

			String getAllSQL = "SELECT * FROM `java project - coupon system`.customers";
			PreparedStatement pStatement = connection.prepareStatement(getAllSQL);
			ResultSet result = pStatement.executeQuery();
			if(result != null){
				while (result.next()) {
					Customer customer = new Customer();
					customer.setId(result.getInt(1));
					customer.setLastName(result.getString(2));
					customer.setFirstName(result.getString(3));
					customer.setPassword(result.getString(4));
					customers.add(customer);
				}
			}
		} catch (SQLException | InterruptedException e) {
			throw new SQLException("Failed to retrieve all Customers in the database.");
		} finally {
			ConnectionPool.getSingeltonInstance().restoreConnection(connection);
		}
		return customers;
	}
// get a specific customer
	@Override
	public Customer getOneCustomer(int CustomerID) throws SQLException {
		Customer customer = new Customer();
		try {
			connection = ConnectionPool.getSingeltonInstance().getConnection();
			String getSQL = "SELECT * FROM `java project - coupon system`.customers WHERE ID=?";
			PreparedStatement pStatement = connection.prepareStatement(getSQL);
			pStatement.setLong(1, CustomerID);
			ResultSet result = pStatement.executeQuery();
			if (result != null) {
				while (result.next()) {
					customer.setLastName(result.getString("LASTNAME"));
					customer.setFirstName(result.getString("FIRSTNAME"));
					customer.setPassword(result.getString("PASSWORD"));
					customer.setId(CustomerID);
				}
			System.out.println("Customer " + customer.getLastName()+ customer.getFirstName() + " was retrieved!");
			}
		} catch (SQLException | InterruptedException e) {
			throw new SQLException("Failed to retrieve Customer.");
		} finally {
			ConnectionPool.getSingeltonInstance().restoreConnection(connection);
		}
		return customer;
	}// get a cupon from specific customer
	public Collection<Integer> getCustomerCoupons(int CustomerID) throws SQLException {
		Collection<Integer> CustCouponsId = new ArrayList<>();
		try {
			connection = ConnectionPool.getSingeltonInstance().getConnection();

			String getCouponsSQL = "SELECT ID_COUPON FROM `java project - coupon system`.coupons_vs_customers "
									+ "WHERE ID_CUSTOMER = ?";
			PreparedStatement pStatement = connection.prepareStatement(getCouponsSQL);
			pStatement.setInt(1, CustomerID);
			ResultSet result = pStatement.executeQuery();
			if(result != null){
				while (result.next()) {
					CustCouponsId.add(result.getInt("ID_COUPON"));
				}
			}
		} catch (SQLException | InterruptedException e) {
			throw new SQLException("Failed to retrieve Customer's Coupons.");
		} finally {
			ConnectionPool.getSingeltonInstance().restoreConnection(connection);
		}
		return CustCouponsId;
	}

	// link between a customer and acupon
	public void linkCustomerCoupon(int customerId, int couponId) throws SQLException {
		try {
			connection = ConnectionPool.getSingeltonInstance().getConnection();
			String linkSQL = "INSERT INTO `java project - coupon system`.coupons_vs_customers (CUSTOMER_ID , COUPON_ID)"
								+ " values (?,?)";
			PreparedStatement pStatement = connection.prepareStatement(linkSQL);
			pStatement.setLong(1, customerId);
			pStatement.setLong(2, couponId);
			pStatement.executeUpdate();
			System.out.println("Customer " + customerId + " was linked with coupon " + couponId);
		} catch (SQLException | InterruptedException e) {
			throw new SQLException("Failed to link Customer and Coupon.");
		} finally {
			ConnectionPool.getSingeltonInstance().restoreConnection(connection);
		}
	}

	//unlink all cupon from a customer
	public void unlinkAllCustomerCoupon(int customerId) throws SQLException {
		try {
			connection = ConnectionPool.getSingeltonInstance().getConnection();

			String linkSQL = "DELETE FROM `java project - coupon system`.coupons_vs_customers WHERE 'CUSTOMER_ID'=?";
			PreparedStatement pStatement = connection.prepareStatement(linkSQL);
			pStatement.setLong(1, customerId);
			pStatement.executeUpdate();
			System.out.println("Customer " + customerId + " was unlinked from all coupons");
		} catch (SQLException | InterruptedException e) {
			throw new SQLException("Failed to unlink Customer from its Coupons.");
		} finally {
			ConnectionPool.getSingeltonInstance().restoreConnection(connection);
		}
	}
}
