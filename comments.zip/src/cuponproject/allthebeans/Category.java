
package cuponproject.allthebeans;

public enum Category 
{
	FOOD,ELECTRICITY,RESTAURANT,VACATION

}
