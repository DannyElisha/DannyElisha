package cuponproject.loginmaneger;

import cuponproject.alltheconnectionpool.ConnectionPool;

public class LoginManeger {
	private static LoginManeger singeltonInstance=null;

	public LoginManeger() {
		super();
	}
	public static LoginManeger getSingeltonInstance() {
		if (singeltonInstance==null)
			synchronized (LoginManeger.class) {
			if (singeltonInstance==null) {
				singeltonInstance= new LoginManeger();
			}	
			}
		return singeltonInstance;
	}
	
}
