package cuponproject.loginmaneger;

public enum ClientType {
	ADMINISTRATOR,COMPANY,CUSTOMER
}
