package cuponproject.allthedao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import cuponproject.allthebeans.Coupon;

//take java beanz(cupons) and make sql querys  and thanks to that we can make CRUD action

public interface CuponsDAO 
{	
	 void addCoupon(Coupon coupon) throws SQLException;
	
	 void updateCoupon(Coupon coupon) throws SQLException;
	
	 void deleteCoupon(Coupon coupon) throws SQLException;
	
	 Collection<Coupon> getAllCoupons() throws SQLException;
	
	 Coupon getCoupon(int couponID) throws SQLException;
	
	 void addCouponPurchase(int customerID, int couponID)throws SQLException; 
	
	 void deleteCouponPurcahse(int customerID, int couponID) throws SQLException;

	void removeCompanyCoupon(int couponId) throws SQLException;
	







}
